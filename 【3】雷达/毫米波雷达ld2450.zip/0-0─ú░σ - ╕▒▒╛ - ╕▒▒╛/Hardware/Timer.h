#ifndef __TIMER_H
#define __TIMER_H

void LD240_show_Init(void);
void LED_PWM_Init(void);
void LED_contorl(uint16_t Compare1,uint16_t Compare2 );

#endif
