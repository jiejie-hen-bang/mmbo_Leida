#include "stm32f10x.h"                  // Device header

void JQ8900_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART2, ENABLE);
}
void jq8900_SendByte(uint8_t Byte)
{
	USART_SendData(USART2, Byte);
	while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}
/**
 * @brief   ��������
 * @param   music_H ��Ŀ��λ
 * @param   music_L ��Ŀ��λ  
 * @retval  none
 */
void jq8900_playmusic(int16_t music_H,int16_t music_L)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x07);
	jq8900_SendByte(0x02);
	jq8900_SendByte(music_H);
	jq8900_SendByte(music_L);
	jq8900_SendByte(0xB3+music_H+music_L);
}
/**
 * @brief   ��������(0-30)
 * @param   vol ����������С
 * @retval  none
 */
void jq8900_volume_set(int16_t vol)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x13);
	jq8900_SendByte(0x01);
	jq8900_SendByte(vol);
	jq8900_SendByte(0xBE + vol);
}
/**
 * @brief   ������ 
 * @retval  none
 */
void jq8900_volume_add(void)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x14);
	jq8900_SendByte(0x00);
	jq8900_SendByte(0xBE);
}
/**
 * @brief   ������
 * @retval  none
 */
void jq8900_volume_subtract(void)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x14);
	jq8900_SendByte(0x00);
	jq8900_SendByte(0xBf);
}
/**
 * @brief    ��ͣ
 * @retval   none
 */
void jq8900_volume_stop(void)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x03);
	jq8900_SendByte(0x00);
	jq8900_SendByte(0xAD);
}
/**
 * @brief    ����
 * @retval   none
 */
void jq8900_volume_start(void)
{
	jq8900_SendByte(0xAA);
	jq8900_SendByte(0x02);
	jq8900_SendByte(0x00);
	jq8900_SendByte(0xAC);
}
