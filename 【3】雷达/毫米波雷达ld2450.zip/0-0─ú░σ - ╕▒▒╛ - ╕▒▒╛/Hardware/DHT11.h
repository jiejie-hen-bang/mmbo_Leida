#ifndef __DHT11_H
#define __DHT11_H
#include "stm32f10x.h"                  // Device header


#define DHT11_Hight GPIO_SetBits(GPIOB, GPIO_Pin_14)
#define DHT11_Low GPIO_ResetBits(GPIOB, GPIO_Pin_14)
#define Read_Data GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14)
#define OUT GPIO_Mode_Out_PP   //���
#define IN GPIO_Mode_IN_FLOATING //����


void DHT11_Init( GPIOMode_TypeDef GPIO_Mode);
void DHT11_Star(void);
char DHT11_OneData(void);
void Receive_DHT11DATA(void);

#endif

