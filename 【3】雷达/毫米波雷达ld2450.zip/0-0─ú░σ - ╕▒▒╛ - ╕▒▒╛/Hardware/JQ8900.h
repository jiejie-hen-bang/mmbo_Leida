#ifndef __JQ8900_H
#define __JQ8900_H

#include <stdio.h>


void JQ8900_Init(void);
void jq8900_SendByte(uint8_t Byte);
void jq8900_playmusic(int16_t music_H,int16_t music_L);
void jq8900_volume_set(int16_t vol);
void jq8900_volume_add(void);
void jq8900_volume_subtract(void);
void jq8900_volume_stop(void);
void jq8900_volume_start(void);

#endif
