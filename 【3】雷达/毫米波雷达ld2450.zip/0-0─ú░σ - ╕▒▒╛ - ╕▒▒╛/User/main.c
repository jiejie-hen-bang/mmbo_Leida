/**
 * ���ţ�LD_2450---> A9,A10;(ʹ�ö�ʱ��2�ڲ�ͨ����ʱ300msˢ��һ������)
 * 		 LED ------> A0,A1;��TIM5��
 * 		 DHT11 -----> B14
 * 		 GY30 ------> sclb10 sdab5
 * 		jq8900 -----> ����2 a2 a3
 * 
 * 
 */


#include "stm32f10x.h"                  
#include "Delay.h"
#include "LED.h"
#include "lcd.h"
#include "Serial.h"
#include "math.h"
#include <stdio.h>
#include "Timer.h"


extern int16_t x1data,y1data,speed1;
extern int16_t x2data,y2data,speed2;
extern int16_t x3data,y3data,speed3;
extern int32_t dis1data,dis2data,dis3data;

int main(void)
{
	LED_Init();
	delay_init();	//��ʱ��ʼ�� 
	LD240_show_Init();
	LED_PWM_Init();
	
	Serial_Init();

    lcd_init();                 /* ��ʼ��LCD */
	lcd_draw_rectangle(2,10,478,220,RED);
	lcd_fill(2,10,478,220,RED);
	lcd_fill(2,220,478,280,BLUE);
	
	lcd_show_string(140,20,50,10,24,"ren1",BLACK);
	lcd_show_string(270,20,50,10,24,"ren2",BLACK);
	lcd_show_string(400,20,50,10,24,"ren3",BLACK);
	
	lcd_show_string(10,60,50,10,24,"Datax",BLACK);
	lcd_show_string(10,100,50,10,24,"Datay",BLACK);
	lcd_show_string(10,140,50,10,24,"Speed",BLACK);
	lcd_show_string(10,190,100,10,24,"Distance",BLACK);
	
	lcd_show_string(10,240,100,10,24,"Light:",BLACK);
	lcd_show_string(140,248,100,10,16,"LUX",BLACK);
	
	lcd_show_string(200,240,100,10,24,"Humi:",BLACK);
	lcd_show_string(283,248,100,10,16,"RH",BLACK);
	
	lcd_show_string(340,240,100,10,24,"Temp:",BLACK);
	lcd_show_string(424,248,100,10,16,"C",BLACK);
		
	
	while (1)
	{

		
		ld_2450_show();
		
		LED_contorl(80,0);

	}
}
void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)
	{
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
		if(Serial_GetRxFlag() == 1)
		{
			LD2450data1(&x1data,&y1data,&speed1,&dis1data);
			LD2450data2(&x2data,&y2data,&speed2,&dis2data);
			LD2450data3(&x3data,&y3data,&speed3,&dis3data);
		}
	}
	
}
